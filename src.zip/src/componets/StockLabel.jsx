import { useState } from "react";
import "../css/StockLabel.css"

function StockLabel(props){
    const [text, setText] = useState(props.quantity);
    return(
        <div>
            <div className="label">
                <p>{props.name}</p>
                <input 
                    type="text" 
                    value={text}
                    style={{width: "55px", boxSizing: "border-box"}}
                    onChange={(e) => setText(e.target.value)}
                />
                <button>Save</button>
            </div>
        </div>
    );
}

export default StockLabel;